# R Program for Conditional transformations.
# Filename: TransformIF.R

setwd("c:/myRfolder")
load(file = "mydata.RData")
mydata
attach(mydata)

mydata$q4Sagree <- ifelse(q4 == 5, 1, 0)
mydata$q4Sagree

mydata$q4Sagree <- as.numeric(q4 == 5 )
mydata$q4Sagree

mydata$q4agree <- ifelse(q4 >= 4, 1, 0)
mydata$q4agree

mydata$ws1agree <- ifelse(workshop == 1 & q4 >=4 , 1, 0)
mydata$ws1agree

mydata$score <- ifelse(gender == "f",
  (2 * q1) + q2,
  (3 * q1) + q2
)
mydata

# ---Cutting posttest---

detach(mydata)
load("mydata100.RData")
attach(mydata100)
head(mydata100)

# An inefficient approach:
postGroup <- posttest 
postGroup <- ifelse(posttest< 60              , 1, postGroup)
postGroup <- ifelse(posttest>=60 & posttest<70, 2, postGroup)
postGroup <- ifelse(posttest>=70 & posttest<80, 3, postGroup)
postGroup <- ifelse(posttest>=80 & posttest<90, 4, postGroup)
postGroup <- ifelse(posttest>=90              , 5, postGroup)

table(postGroup)

# An efficient approach
postGroup <-
ifelse(posttest <  60                 , 1,
  ifelse(posttest >= 60 &  posttest < 70, 2,
    ifelse(posttest >= 70 &  posttest < 80, 3,
      ifelse(posttest >= 80 &  posttest < 90, 4,
        ifelse(posttest >= 90                 , 5, posttest)
))))
table(postGroup)

# Logical approach
postGroup <- 1+
  (posttest >= 60)+
  (posttest >= 70)+
  (posttest >= 80)+
  (posttest >= 90)
table(postGroup)

# ---Cutting Functions---

# Hmisc cut2 function
library("Hmisc")
postGroup <- cut2(posttest, c(60, 70, 80, 90) )
table(postGroup)

postGroup <- cut2(posttest, g = 5)
table(postGroup)

postGroup <- cut2(posttest, m = 25)
table(postGroup)