# R Program to Write a SAS XPORT File
# and a program to read it into SAS.
# Filename: WriteSAS.R

setwd("c:/myRfolder")
library("foreign")

write.foreign(mydata,
  datafile = "mydataFromR.txt",
  codefile = "mydataFromR.sas",
  package  = "SAS")

# Look at the contents of our new files.
file.show("mydataFromR.txt")
file.show("mydataFromR.sas")