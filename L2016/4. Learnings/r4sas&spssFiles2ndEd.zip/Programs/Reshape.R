# R Program to Reshape Data.
# Filename: Reshape.R

setwd("c:/myRfolder")
load("mydata.RData")
library(reshape)
myChanges <- c(
  q1 = "time1",
  q2 = "time2",
  q3 = "time3",
  q4 = "time4")
mydata <- rename(mydata, myChanges)
detach("package:reshape")
mydata$subject <- factor(1:8)
mydata

# Reshaping from wide to long
library(reshape2)
mylong <- melt(mydata)
mylong

# Again, specifying arguments
mylong <- melt(mydata, 
  id.vars      = c("subject", "workshop", "gender"),
  measure.vars = c("time1", "time2", "time3", "time4"),
  value.name   = "variable")
mylong  

# Reshaping from long to wide
mywide <- dcast(mylong, subject + workshop + gender ~ variable)
mywide

# ---Two Time Variables---  
load("mydata.RData")
mydata$subject <- factor(1:8)
library(reshape)
myChanges <- c(
  q1 = "M1_L1",
  q2 = "M1_L2",
  q3 = "M2_L1",
  q4 = "M2_L2")
mydata <- rename(mydata, myChanges)
detach("package:reshape")
mydata

library(reshape2)
mylong2 <- melt(mydata)
mylong2  

# Same thing with arguments specified
mylong2 <- melt(mydata, 
  id.vars      = c("subject", "workshop", "gender"),
  measure.vars = c("M1_L1", "M1_L2", "M2_L1", "M2_L2"),
  value.name   = "value") 
mylong2

mylong2$method <- rep( c("M1", "M2"), each=16, times=1)
mylong2$level  <- rep( c("L1", "L2"), each=8,  times=2)
mylong2
mylong2$variable <- NULL

# Reshape to wide
mywide2 <- dcast(mylong2, gender + workshop + subject ~ method + level)
mywide2
mywide2[ order(mywide2$subject), ]

# Aggregation via reshape

dcast(mylong2, gender + workshop ~ method + level, 
  mean, na.rm = TRUE)
dcast(mylong2, gender + workshop ~ method, 
  mean, na.rm = TRUE)
dcast(mylong2, workshop ~ ., 
  mean, na.rm = TRUE)