# R Program of Basic Statistical Tests.
# Filename: Statistics.R

setwd("c:/myRfolder")
load("mydata100.Rdata")
attach(mydata100)
options(linesize = 63)

head(mydata100)

# ---Frequencies & Univariate Statistics---

# Deducer's frequencies() function

# The easy way using the Hmisc package.
library("Hmisc")
describe(mydata100)

# R's built-in function.
summary(mydata100)

# The flexible way using built-in functions.

table(workshop)
table(gender)

# Proportions of valid values.
prop.table( table(workshop) )
prop.table( table(gender) )

# Rounding off proportions.
round( prop.table( table(gender) ), 2 )

# Converting proportions to percents.
round( 100* ( prop.table( table(gender) ) ) )

# Frequencies & Univariate
summary(mydata100)

# Means & Std Deviations
options(width=63)
sapply( mydata100[3:8], mean,  na.rm = TRUE)
sapply( mydata100[3:8], sd,    na.rm = TRUE)

# ---Crosstabulations---

# The easy way, using the gmodels package.
library("gmodels")
CrossTable(workshop, gender,
  chisq = TRUE, format = "SAS")

# The flexible way using built-in functions.

# Counts
myWG <- table(workshop, gender)
myWG     # Crosstabulation format.
myWGdata <- as.data.frame(myWG)
myWGdata # Summary or Aggregation format.

chisq.test(myWG)

# Row proportions.
prop.table(myWG, 1)

# Column proportions.
prop.table(myWG, 2)

# Total proportions.
prop.table(myWG)

# Rounding off proportions.
round( prop.table(myWG, 1), 2 )

# Row percents.
round( 100* ( prop.table(myWG, 1) ) )

# Adding Row and Column Totals.
addmargins(myWG, 1)
addmargins(myWG, 2)
addmargins(myWG)

# ---Correlation & Linear Regression---

# The rcorr.adjust function from the R Commander package
library("Rcmdr")
load("mydata.RData")
rcorr.adjust( mydata[3:6] )

# Spearman correlations.
rcorr.adjust( mydata[3:6], type = "spearman" )

# The built-in cor function.
cor( mydata[3:6],
  method = "pearson", use = "pairwise")

# The built-in cor.test function
cor.test(mydata$q1, mydata$q2, use = "pairwise")

# Linear regression.
lm( q4 ~ q1 + q2 + q3, data = mydata100)

myModel <- lm( q4 ~ q1 + q2 + q3, data = mydata100 )
myModel
summary(myModel)
anova(myModel) #Same as summary result.

# Set graphics parameters for 4 plots (optional).
par( mfrow = c(2, 2), mar = c(5, 4, 2, 1) + 0.1 )

plot(myModel)

# Set graphics parameters back to default settings.
par( mfrow = c(1, 1), mar = c(5, 4, 4, 2) + 0.1 )

# Repeat the diagnostic plots and route them
# to a file.
postscript("LinearRegDiagnostics.eps")
par( mfrow = c(2,2), mar = c(5, 4, 2, 1) + 0.1 )
plot(myModel)
dev.off()
par( mfrow = c(1, 1), mar = c(5, 4, 4, 2) + 0.1 )

myNoMissing <- na.omit(mydata100[ ,c("q1","q2","q3","q4")] )
myFullModel    <- lm( q4 ~ q1 + q2 + q3, data = myNoMissing)
myReducedModel <- lm( q4 ~ q1,           data = myNoMissing)
anova( myReducedModel, myFullModel)


# ---Group Comparisons---

# Independent samples t-test.
t.test( q1 ~ gender, data = mydata100)

# Same test; requires attached data.
t.test( q1[gender == "Male"],
        q1[gender == "Female"] )

# Same test using with() function.	
with(mydata100,
  t.test( q4[ which(gender == "Male") ],
          q4[ which(gender == "Female") ] )
)

# Same test using subset() function.
t.test(
  subset(mydata100, gender == "Male", select = q4),
  subset(mydata100, gender == "Female", select = q4)
)

# Paired samples t-test.
t.test(posttest, pretest, paired = TRUE)

# Equality of variance.
library("car")
levene.test(posttest, gender)

var.test(posttest ~ gender)

# Wilcoxon/Mann-Whitney test.
wilcox.test( q1 ~ gender, data = mydata100)
# Same test specified differently.
wilcox.test( q1[gender == 'Male'],
             q1[gender == 'Female'] )
aggregate( q1, data.frame(gender),
  median, na.rm = TRUE)

# Wilcoxon signed rank test.
wilcox.test( posttest, pretest, paired = TRUE)
median(pretest)
median(posttest)

# Sign test.
library("PASWR")
SIGN.test(posttest, pretest, conf.level = .95)

# Analysis of Variance (ANOVA).
aggregate( posttest,
  data.frame(workshop),
  mean, na.rm = TRUE)

aggregate( posttest,
  data.frame(workshop),
  var, na.rm = TRUE)

library("car")
levene.test(posttest, workshop)

myModel <- aov(posttest ~ workshop,
  data = mydata100)
myModel

anova(myModel)
summary(myModel)  # same as anova result.

# type III sums of squares
library("car")
Anova(myModel, type = "III")

pairwise.t.test(posttest, workshop)

TukeyHSD(myModel, "workshop")
plot( TukeyHSD(myModel, "workshop") )

# Repeat TukeyHSD plot and route to a file.
postscript("TukeyHSD.eps")
plot( TukeyHSD(myModel, "workshop") )
dev.off()

# Set graphics parameters for 4 plots (optional).
par( mfrow = c(2, 2), mar = c(5, 4, 2, 1) + 0.1 )
plot(myModel)
# Set graphics parameters back to default settings.
par( mfrow = c(1, 1), mar = c(5, 4, 4, 2) + 0.1 )

# Nonparametric oneway ANOVA using
# the Kruskal-Wallis test.
kruskal.test(posttest ~ workshop)

pairwise.wilcox.test(posttest, workshop)

aggregate( posttest,
  data.frame(workshop),
  median, na.rm = TRUE)