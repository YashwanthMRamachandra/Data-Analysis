# R Program for Selecting Both Variables and Observations.
# Filename: SelectingVarsAndObs.R

setwd("c:/myRfolder")
load(file = "mydata.RData")
attach(mydata)
print(mydata)

# ---The subset Function---

print(
  subset(mydata,
    subset = gender == "m",
    select = c(workshop, q1:q4) )
)

myMalesWQ <- subset(mydata,
    subset = gender == "m",
    select = c(workshop, q1:q4)
)

print(myMalesWQ)
summary(myMalesWQ)

# ---Logic for Obs, Names for Vars---

print(
  mydata[ which(gender == "m") ,
          c("workshop", "q1", "q2", "q3", "q4") ]
)

myMales <- which(gender == "m")
myVars  <- c("workshop", "q1", "q2", "q3", "q4")
myVars
myVars <- c("workshop", paste("q", 1:4, sep = "") )
myVars

print( mydata[myMales, myVars] )
print( mydata[myMales, ] )
print( mydata[ , myVars] )

myMalesWQ <- mydata[myMales, myVars]
print(myMalesWQ)

# ---Row and Variable Names---

print( mydata[
  c("5", "6", "7", "8"),
  c("workshop", "q1", "q2", "q3", "q4")
] )

myMales <- c("5", "6", "7", "8")
myVars  <- c("workshop", "q1", "q2", "q3", "q4")

print( mydata[myMales, myVars] )
print( mydata[myMales, ] )
print( mydata[ , myVars] )

# ---Numeric Index Vectors---

print( mydata[ c(5, 6, 7, 8), c(1, 3, 4, 5, 6) ] )
print( mydata[ 5:8, c(1, 3:6) ] )

myMales <- c(5,6,7,8)
myVars  <- c(1,3:6)

print( mydata[myMales, myVars] )
print( mydata[myMales, ] )
print( mydata[ , myVars] )

# ---Saving and Loading Subsets---

myMalesWQ <- subset(mydata,
    subset = gender == "m",
    select = c(workshop,q1:q4)
)

save(mydata, myMalesWQ, file = "myBoth.RData")
load("myBoth.RData")

save(myMalesWQ, file = "myMalesWQ.RData")
load("myMalesWQ.RData")

print(myMalesWQ)