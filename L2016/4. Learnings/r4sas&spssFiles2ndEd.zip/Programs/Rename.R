# R Program for Renaming Variables.
# Filename: Rename.R

setwd("c:/myRfolder")
load(file = "mydata.RData")
mydata

# Using the data editor.

fix(mydata)
mydata

# Restore original names for next example.
names(mydata) <- c("group", "gender",
  "q1", "q2", "q3", "q4")

# Using the reshape package.

library("reshape")
myChanges <- c(q1 = "x1", q2 = "x2", q3 = "x3", q4="x4")
myChanges

mydata <- rename(mydata, myChanges)
mydata

# Restore original names for next example.
names(mydata) <- c("group", "gender",
  "q1", "q2", "q3", "q4")

# The standard R approach.
names(mydata) <- c("group", "gender",
  "x1", "x2", "x3", "x4")
mydata

# Restore original names for next example.
names(mydata) <- c("group", "gender",
  "q1", "q2", "q3", "q4")

# Using the edit function.
names(mydata) <- edit( names(mydata) )
mydata

# Restore original names for next example.
names(mydata) <- c ("workshop", "gender",
  "q1", "q2", "q3", "q4")

#---Selecting Variables by Index Number---

mynames <- names(mydata)

# Data.frame adds index numbers to names.
data.frame(mynames))

# Then fill in index numbers in brackets.
mynames[3] <- "x1"
mynames[4] <- "x2"
mynames[5] <- "x3"
mynames[6] <- "x4"

# Finally, replace old names with new.
names(mydata) <- mynames
mydata

# Restore original names for next example.
names(mydata) <- c("group", "gender",
  "q1", "q2", "q3", "q4")

#---Selecting Variables by Name---

# Make a copy to work on.
mynames <- names(mydata)
mynames

# Replace names in copy.
mynames[ mynames == "q1" ] <- "x1"
mynames[ mynames == "q2" ] <- "x2"
mynames[ mynames == "q3" ] <- "x3"
mynames[ mynames == "q4" ] <- "x4"
mynames

# Then replace the old names.
names(mydata) <- mynames
mydata

# Restore original names for next example.
names(mydata) <- c ("group", "gender",
  "q1", "q2", "q3", "q4")

#---Same as Above, but Confusing!---

names(mydata)[names(mydata) == "q1"] <- "x1"
names(mydata)[names(mydata) == "q2"] <- "x2"
names(mydata)[names(mydata) == "q3"] <- "x3"
names(mydata)[names(mydata) == "q4"] <- "x4"
print(mydata)

# Restore original names for next example.
names(mydata) <- c("group", "gender",
  "q1", "q2", "q3", "q4")

#---Replacing Many Numbered Names---

# Examine names
names(mydata)

# Generate new numbered names.
myXs <- paste( "x", 1:4, sep="")
myXs

# Find out where to put the new names.
myA <- which( names(mydata) == "q1" )
myA
myZ <- which( names(mydata) == "q4" )
myZ

# Replace names at index locations.
names(mydata)[myA:myZ] <- myXs

#remove the unneeded objects.
rm(myXs, myA, myZ)