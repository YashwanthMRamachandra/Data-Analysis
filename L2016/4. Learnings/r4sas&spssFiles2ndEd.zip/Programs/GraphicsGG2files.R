# Grammar of Graphics in R using ggplot2.
# This version writes the graphs to files (hence the name "2files")

# GraphicsGG.R

setwd("c:/myRfolder")
load(file = "mydata100.Rdata")
detach(mydata100) #In case I'm running repeatedly.

# Get rid of missing values for facets
mydata100 <- na.omit(mydata100)
attach(mydata100) 
library(ggplot2)

setwd("C:/Users/Bob/Documents/Books/R for SAS and SPSS Users/R for SAS & SPSS - 2nd Edition/r4sas/chapter16")

# ---Default qplots---
postscript("GGqplotFunction.eps",
  paper="special",width=5.75,height=8.0)
grid.newpage()  # clear page
# Sets up a 3 by 2 grid to plot into.
pushViewport( viewport(layout = grid.layout(3, 2) ) )

myPlot <- qplot(workshop,  # Bar plot
  main="qplot(workshop)")  
print(myPlot, vp = viewport(
  layout.pos.row = 1,
  layout.pos.col = 1) )
  
myPlot <- qplot(pretest,  
  main="qplot(posttest)" )    # Histogram
print(myPlot, vp = viewport(
  layout.pos.row = 1,
  layout.pos.col = 2) )

myPlot <- qplot(workshop, gender, 
  main="qplot(workshop, gender)" ) # Useless points
print(myPlot, vp = viewport(
  layout.pos.row = 2,
  layout.pos.col = 1) )

myPlot <- qplot(workshop, posttest, 
  main="qplot(workshop, posttest)" )  # Strip plot
print(myPlot, vp = viewport(
  layout.pos.row = 2,
  layout.pos.col = 2) )
  
myPlot <- qplot(posttest, workshop, 
  main="qplot(posttest, workshop)" )  # Strip plot
print(myPlot, vp = viewport(
  layout.pos.row = 3,
  layout.pos.col = 1) )

myPlot <- qplot(pretest, posttest,
  main="qplot(pretest, posttest)" )
print(myPlot, vp = viewport(
  layout.pos.row = 3,
  layout.pos.col = 2) )

dev.off()

# ---Barplots---

# Barplot - Vertical

qplot(workshop, geom="bar")
ggsave("GGbarWorkshop.eps", width=4, height=4)

ggplot(mydata100, aes( workshop ) ) + 
  geom_bar() 

# Barplot - Horizontal

qplot(workshop, geom="bar") + coord_flip()

ggplot(mydata100, aes( workshop ) ) + 
  geom_bar() + coord_flip()
ggsave("GGbarFlipped.eps", width=4, height=4)

# Barplot - Single Bar Stacked

qplot(factor(""), fill=workshop, 
  geom="bar", xlab="") +
  scale_fill_grey(start=0, end=1)

ggplot(mydata100, 
  aes(factor(""), fill=workshop) ) +
  geom_bar() + 
  scale_x_discrete("") +
  scale_fill_grey(start=0, end=1)
ggsave("GGbarStacked.eps", width=4, height=4)

# Pie charts, same as stacked bar but polar coordinates

# This is almost it. See book for details.
qplot(factor(""), fill=workshop, 
  geom="bar", xlab="") +
  coord_polar(theta="y") +
  scale_fill_grey(start=0, end=1)

ggplot(mydata100, 
  aes( factor(""), fill=workshop ) ) + 
  geom_bar( width=1 ) + 
  scale_x_discrete("") +
  coord_polar(theta="y") +
  scale_fill_grey(start=0, end=1)
ggsave("GGpie.eps", width=4, height=4)

# Barplots - Grouped

qplot(gender, geom="bar", 
    fill=workshop, position="stack") + 
  scale_fill_grey(start = 0, end = 1)
qplot(gender, geom="bar", 
    fill=workshop, position="fill")  + 
  scale_fill_grey(start = 0, end = 1)
qplot(gender, geom="bar", 
    fill=workshop, position="dodge") + 
  scale_fill_grey(start = 0, end = 1)

ggplot(mydata100, aes(gender, fill=workshop) ) + 
  geom_bar(position="stack") + 
  scale_fill_grey(start = 0, end = 1)
ggplot(mydata100, aes(gender, fill=workshop) ) + 
  geom_bar(position="fill") + 
  scale_fill_grey(start = 0, end = 1)
ggplot(mydata100, aes(gender, fill=workshop ) ) + 
  geom_bar(position="dodge") + 
  scale_fill_grey(start = 0, end = 1)

# Barplots - Faceted

qplot(workshop, geom="bar", facets=gender~.) 

ggplot(mydata100, aes(workshop) ) +
  geom_bar() + facet_grid( gender~. )
ggsave("GGbarFaceted.eps", width=4.75, height=4.75)

# Barplots - Pre-summarized data

qplot( factor(c(1,2)), c(40, 60), geom="bar",
  xlab="myGroup", ylab="myMeasure")

myTemp <- data.frame( 
  myGroup=factor( c(1,2) ), 
  myMeasure=c(40, 60) 
)
myTemp
ggplot(data=myTemp, aes(myGroup, myMeasure) ) + 
  geom_bar() 
ggsave("GGbar4060.eps", width=4, height=4)


# ---Dotcharts---

qplot(workshop, stat="bin",
     facets=gender~., size=4 ) +
 coord_flip()

# This is the qplot code that will do a dotchart.
# It's the same as above but adds geom="point".

qplot(workshop, stat="bin",
     facets=gender~., geom="point", size=4 ) +
 opts(legend.position="none") +
 coord_flip()

# The ggplot code was unaffected by this change

ggplot(mydata100, 
   aes(workshop, ..count.. ) ) +
   geom_point(stat="bin", size=4) + coord_flip()+ 
   facet_grid( gender~. ) 
ggsave("GGdotchart.eps", width=4, height=4)

# ---Adding Titles and Labels---

qplot(workshop, geom="bar",
  main="Workshop Attendance", 
  xlab="Statistics Package \nWorkshops")

ggplot(mydata100, aes(workshop, ..count..)) +
  geom_bar() +
  opts( title="Workshop Attendance" ) +
  scale_x_discrete("Statistics Package \nWorkshops")
ggsave("GGtitles.eps", width=4, height=4)

# Example not in book: labels of continuous scales.
ggplot(mydata100, aes(pretest,posttest ) ) +
  geom_point() + 
  scale_x_continuous("Test Score Before Training") +
  scale_y_continuous("Test Score After Training")  +
  opts( title="The Relationship is Linear" )

# ---Histograms and Density Plots---

# Simle Histogram
qplot(posttest, geom="histogram")

ggplot(mydata100, aes(posttest) ) +
  geom_histogram()
ggsave("GGhist.eps", width=4, height=4)

# Histogram with more bars.
qplot(posttest, geom="histogram", binwidth=0.5)

ggplot(mydata100, aes(posttest) ) + 
  geom_histogram( binwidth=0.5 )
ggsave("GGhist2.eps", width=4, height=4)

# Density plot
qplot(posttest, geom="density")

ggplot(mydata100, aes(posttest)) + 
  geom_density()
ggsave("GGdensity.eps", width=4, height=4)

# Histogram with Density

qplot(data=mydata100,posttest, ..density.., 
  geom=c("histogram","density") )
 
ggplot(data=mydata100) +
  geom_histogram( aes(posttest, ..density..) ) +
  geom_density(   aes(posttest, ..density..) ) +
  geom_rug( aes(posttest) ) 
ggsave("GGhistDensity.eps", width=4, height=4)


# Histogram - Separate plots by group

qplot(posttest, geom="histogram", facets=gender~.)

ggplot(mydata100, aes(posttest) ) + 
  geom_histogram() + facet_grid( gender~. )
ggsave("GGhistFaceted.eps", width=4, height=4)

# Histogram with Stacked Bars

qplot( posttest, geom="histogram", fill=gender ) +
  scale_fill_grey(start = 0, end = 1)

ggplot(mydata100, aes(posttest, fill=gender) ) + 
  geom_bar() + 
  scale_fill_grey(start = 0, end = 1)
ggsave("GGhistOverlaid.eps", width=4.75, height=4)
 

# ---QQ plots--- 
qplot(sample=posttest, stat="qq")

ggplot( mydata100, aes(sample=posttest) ) + 
  stat_qq() 
ggsave("GGqq.eps", width=4.0, height=4)

# ---Strip plots---

# The developer had added more jitter by default
# since the book was written. That is good if you
# have lots of data or lots of groups. In our case,
# I do not like the defaults:

qplot( factor(""), posttest, geom="jitter", xlab="") 

ggplot(mydata100, aes(factor(""), posttest) ) + 
  geom_jitter() +
  scale_x_discrete("")
ggsave("GGstrip1.eps", width=4.0, height=4)

# Strip plot by group.
qplot(workshop, posttest, geom="jitter")

ggplot(mydata100, aes(workshop, posttest) ) + 
  geom_jitter()

# Here I do all the strip plots again, limiting
# the amount of jitter to recreate the plots in
# the book.

qplot( factor(""), posttest, data = mydata100, xlab="",
  position=position_jitter(width=.02)) 

ggplot(mydata100, aes(factor(""), posttest) ) +
 geom_jitter(position=position_jitter(width=.02)) +
 scale_x_discrete("")
ggsave("GGstrip1.eps", width=4, height=4)

# Strip plot by group.
# Note that I am increasing the jitter width from 
# .02 to .08 because there is only one fourth the
# room for each graph.

qplot(workshop, posttest, data = mydata100, xlab="",
  position=position_jitter(width=.08))

ggplot(mydata100, aes(workshop, posttest) ) +
 geom_jitter(position=position_jitter(width=.08)) +
 scale_x_discrete("")
ggsave("GGstrip2.eps", width=4.75, height=4)


# ---Scatterplots---

# Simple scatterplot

qplot(pretest, posttest)
qplot(pretest, posttest, geom="point")

ggplot(mydata100, aes(pretest, posttest)) + 
  geom_point() 

# Scatterplot connecting points sorted on x.
qplot( pretest, posttest, geom="line")

ggplot(mydata100, aes(pretest, posttest) ) + 
  geom_line() 

# Scatterplot connecting points in data set order.

qplot( pretest, posttest, geom="path")

ggplot(mydata100, aes(pretest, posttest) ) + 
  geom_path() 

# Scatterplot with skinny histogram-like bars to X axis.

#qplot does not do this in 0.5.7 but will in future release:
qplot(pretest,posttest, 
  xend=pretest, yend=50, 
  geom="segment")

ggplot(mydata100, aes(pretest,    posttest) ) + 
  geom_segment( aes(  pretest,    posttest, 
                 xend=pretest,    yend=50) )

# Scatterplot with jitter
qplot(q1, q4) #First without

# This is the code from the book, which no longer works
qplot(q1, q4, position=position_jitter(x=5,y=5) ) 

# This is the new way to specify the plot. You can try
# different amounts of jitter of course.
qplot(q1, q4, position=position_jitter(width=.3,height=.3))

ggplot(mydata100, aes(x=q1, y=q2) ) +
 geom_point(position=position_jitter(width=.3,height=.3))

# Scatterplot on large data sets

pretest2   <- round( rnorm( n=5000, mean=80, sd=5) ) 
posttest2  <- round( pretest2 + rnorm( n=5000, mean=3, sd=3) )
pretest2[pretest2>100] <- 100
posttest2[posttest2>100] <- 100
temp=data.frame(pretest2,posttest2)

# Small, jittered, transparent points.

qplot(pretest2, posttest2, data = temp, 
  size = I(1), colour = I(alpha("black", 0.15)), 
  geom = "jitter")

# Or in the next version of ggplot2: 

qplot(pretest2, posttest2, data = temp, 
  size = I(1), alpha = I(0.15), 
  geom = "jitter")


ggplot(temp, aes(pretest2, posttest2), 
  size=2, position = position_jitter(x=2,y=2) ) +
  geom_jitter(colour=alpha("black",0.15) )
ggsave("GGtransparency.pdf", width=4.0, height=4.0)

ggplot(temp, aes(pretest2, posttest2)+
 geom_point(colour=alpha("black",0.15),
   position=position_jitter(width=.3,height=.3)) )

# Hexbin plots

# In qplot using default colors.
qplot(pretest2, posttest2, geom="hex", bins=30)

# This works too:
ggplot(temp, aes(pretest2, posttest2))  +
  stat_binhex(bins = 30)

# In ggplot, switching to greyscale.
ggplot(temp, aes(pretest2, posttest2))  +
  geom_hex( bins=30 ) +
  scale_fill_continuous(
    low = "grey80", high = "black") 
ggsave("GGhex.eps", width=4.0, height=4.0)


# Using density contours and small points.

qplot(pretest2, posttest2, data=temp, size = I(1), 
  geom=c("point","density2d"))

ggplot(temp, aes( x=pretest2, y=posttest2) ) +
 geom_point( size=1 ) + geom_density2d()
ggsave("GGdensityContours.eps", width=4.0, height=4.0)

# Density shading 
ggplot(temp, aes( x = pretest2, y = posttest2) ) +
  stat_density2d(geom = "tile",
    aes(fill = ..density..), contour = FALSE) +
  scale_fill_continuous(
    low = "grey80", high = "black") 
ggsave("GGdensityShading.eps", width=4.0, height=4.0)	

rm(pretest2,posttest2,temp)

# Scatterplot with regression line, 95% confidence intervals. 

qplot(pretest, posttest, 
  geom=c("point","smooth"), method=lm ) 

# Using the png function (tiny fonts result):
png("GGregCI.png", res=600, width=2400, height=2400)
ggplot(mydata100, aes(pretest, posttest) ) + 
  geom_point() + geom_smooth(method=lm)
dev.off()

# Again, using the ggsave function (small fonts result):
ggplot(mydata100, aes(pretest, posttest) ) + 
  geom_point() + geom_smooth(method=lm)
ggsave("GGregCI.png", width=4.0, height=4.0)

# Scatterplot with regression line but NO confidence intervals.

qplot(pretest, posttest, 
  geom=c("point","smooth"), 
  method=lm, se=FALSE )

ggplot(mydata100, aes(pretest, posttest) ) + 
  geom_point() + 
  geom_smooth(method=lm, se=FALSE)
ggsave("GGregNoCI.eps", width=4.0, height=4.0)

# Scatter with x=y line 

qplot(pretest, posttest, 
  geom=c("point","abline"), 
  intercept=0, slope=1 ) 

ggplot(mydata100, aes(pretest, posttest) ) +
  geom_point()+
  geom_abline(intercept=0, slope=1)
ggsave("GGslope1.eps", width=4.0, height=4.0)

# Scatter with vertical or horizontal lines

# When the book was written, qplot required the 
# values to be equal. Now it does not using 
# xintercept and yintercept.

qplot(pretest, posttest,
 geom=c("point", "vline", "hline"),
 xintercept=75, yintercept=75)
ggsave("GGref75.eps", width=4.0, height=4.0)

ggplot(mydata100, aes(pretest, posttest)) + 
  geom_point() + 
  geom_vline( xintercept=75 ) + 
  geom_hline( yintercept=75 )
ggsave("GGref75.eps", width=4.0, height=4.0)

# Scatterplot with a set of vertical lines

qplot(pretest, posttest, type="point") + 
  geom_vline( xintercept=seq(from=70,to=80,by=2) )
ggsave("GGvrefs.eps", width=4.0, height=4.0)

ggplot(mydata100, aes(pretest, posttest)) + 
  geom_point() + 
  geom_vline( xintercept=seq(from=70,to=80,by=2) )
ggsave("GGvrefs.pdf", width=4.0, height=4.0)

# Scatter plotting text labels

qplot(pretest, posttest, geom="text", 
  label=rownames(mydata100) )

ggplot(mydata100, 
  aes(pretest, posttest, 
  label=rownames(mydata100) ) ) + 
  geom_text()
ggsave("GGlabels.eps", width=4.0, height=4.0)


# Scatterplot with different point shapes for each group.

qplot(pretest, posttest, shape=gender)

ggplot(mydata100, aes(pretest, posttest) ) + 
  geom_point( aes(shape=gender ) )
ggsave("GGshape.eps", width=4.5, height=3.5)

# Scatterplot with regressions fit for each group. 

qplot(pretest, posttest, 
  geom   = c("smooth", "point"), 
  method = "lm", shape = gender,
  linetype  = gender)

ggplot(mydata100, 
  aes(pretest, posttest, shape = gender,
  linetype = gender) ) + 
  geom_smooth(method = "lm") + 
  geom_point()
ggsave("GGregShape.pdf", width=4.5, height=3.5)

# Again using .png to capture transparency
ggplot(mydata100, 
  aes(pretest, posttest, shape = gender,
  linetype = gender) ) + 
  geom_smooth(method = "lm") + 
  geom_point()
ggsave("GGregShape.png", width=4.0, height=3.0, dpi=600)

# Scatterplot faceted for groups

qplot(pretest, posttest, 
  geom=c("smooth", "point"), 
  method="lm", shape=gender, 
  facets=workshop~gender)

ggplot(mydata100, 
  aes(pretest, posttest, shape=gender) ) +
  geom_smooth( method="lm" ) + geom_point() +
  facet_grid( workshop~gender )
ggsave("GGregWG.pdf", width=4.75, height=4.75)

# Scatterplot matrix 

plotmatrix( mydata100[3:8] )

# Small points & lowess fit.
plotmatrix( mydata100[3:8], aes( size=1 ) ) + 
  geom_smooth() +
  opts(legend.position="none")
ggsave("GGmatrix.pdf", width=4.75, height=4.75)

# Shape and gender fits.
plotmatrix( mydata100[3:8], 
  aes( shape=gender ) ) + 
  geom_smooth(method=lm) +
ggsave("GGmatrix.pdf", width=4.75, height=4.75)

# ---Boxplots---

# Boxplot of one variable

qplot(factor(""), posttest, 
  geom="boxplot", xlab="") 

ggplot(mydata100, 
  aes(factor(""), posttest) ) +
  geom_boxplot() +
  scale_x_discrete("")
ggsave("GGbox.eps", width=4.0, height=4.0)

# Boxplot by group

qplot(workshop, posttest, geom="boxplot" )

ggplot(mydata100, 
  aes(workshop, posttest) ) + 
  geom_boxplot()

# Boxplot by group with jitter

# The jitter in this is wider than when the
# book was published. To control it, you need
# to use ggplot.
qplot(workshop, posttest, 
  geom=c("boxplot","jitter") )


# Here is the ggplot code from the book that
# also results in very wide jitter now.

ggplot(mydata100, 
  aes(workshop, posttest )) + 
  geom_boxplot() + geom_jitter()

# This adjustment makes it look like the plot in the book.

ggplot(mydata100,
 aes(workshop, posttest )) +
 geom_boxplot() +
 geom_jitter(position=position_jitter(width=.1))
ggsave("GGboxWorkshop.eps", width=4.0, height=4.0)

# Boxplot for two-way interaction.

qplot(workshop, posttest, 
  geom="boxplot", fill=gender ) + 
  scale_fill_grey(start = 0, end = 1)

ggplot(mydata100, 
  aes(workshop, posttest) ) + 
  geom_boxplot( aes(fill=gender), colour="grey50") + 
  scale_fill_grey(start = 0, end = 1)
ggsave("GGboxWG.eps", width=4.5, height=3.5)

# Error bar plot

# This is the updated code for qplot.
qplot( as.numeric(workshop), posttest) + 
  geom_jitter(position=position_jitter(width=.1))  +
  stat_summary(fun.y="mean", 
    geom="smooth", se=FALSE) +
  stat_summary(fun.data="mean_cl_normal", 
    geom="errorbar", width=.2)

# This is the updated code for ggplot.
ggplot(mydata100, 
  aes( as.numeric(workshop), posttest ) ) + 
  geom_jitter(size=1,position=position_jitter(width=.1) )  +
  stat_summary(fun.y="mean", 
    geom="smooth", se=FALSE) +
  stat_summary(fun.data="mean_cl_normal", 
    geom="errorbar", width=.2)
ggsave("GGerrorBar.eps", width=4.0, height=4.0)

# This does away with the jitter and looks nice.
ggplot(mydata100, 
  aes( as.numeric(workshop), posttest ) ) + 
  geom_point(size=1)  +
  stat_summary(fun.y="mean", 
    geom="smooth", se=FALSE) +
  stat_summary(fun.data="mean_cl_normal", 
    geom="errorbar", width=.2)

# ---Geographic Maps---
	
library(maps)
library(ggplot2)
myStates <- map_data("state")
head(myStates)
myStates[ myStates$region=="new york", ]

qplot(long, lat, data = myStates, group = group, 
  geom = "path", asp=1)
  
ggplot(data=myStates, aes(long, lat, group=group) )+
  geom_path() +
  coord_map()
ggsave("GGmapEmpty.eps", width=4.0, height=3.0)

myArrests <- USArrests
head(myArrests)

myArrests$region <- tolower( rownames(USArrests) )
head(myArrests)

myBoth <- merge( 
  myStates, 
  myArrests, by = "region")
myBoth[1:4, c(1:5,8)]

myBoth <- myBoth[order(myBoth$order), ]
myBoth[1:4, c(1:5,8)]

qplot(long, lat, data = myBoth, group = group, 
  fill = Assault, geom = "polygon", asp=1) +
  scale_fill_continuous(low = "grey80", high = "black")
  
ggplot(data=myBoth,
    aes(long, lat, fill=Assault, group=group) )+
  geom_polygon() +
  coord_map() +
  scale_fill_continuous(low = "grey80", high = "black")
ggsave("GGmapAssault.eps", width=4.0, height=3.0)  
  

# This puts the two maps in the same display, but they don't look
# very good that way since the 2nd has a legend.
grid.newpage()

# Sets up a 2 by 1 grid to plot into.
pushViewport( viewport(layout=grid.layout(2,1) ) )

# Empty map of USA
myPlot <- ggplot(data=myStates, aes(long, lat, group=group) )+
  geom_path() +
  coord_map()
print(myPlot, vp=viewport(
  layout.pos.row=1, 
  layout.pos.col=1) )

# Map of Assault
myPlot <- ggplot(data=myBoth,
    aes(long, lat, fill=Assault, group=group) )+
  geom_polygon() +
  coord_map() +
  scale_fill_continuous(low = "grey80", high = "black")	
print(myPlot, vp=viewport(
  layout.pos.row=2, 
  layout.pos.col=1) )

dev.off()
	
# ---Logarithmic Axes---

# Change the variables
qplot( log(pretest), log(posttest) )

ggplot(mydata100, 
  aes( log(pretest), log(posttest) ) ) +
  geom_point()

# Change axis labels

qplot(pretest, posttest, log="xy") 

ggplot(mydata100, aes( x=pretest, y=posttest) ) +
  geom_point() + scale_x_log10() + scale_y_log10()

# Change axis scaling

# Tickmarks remain uniformly spaced,
# because scale of data is too limited.

qplot(pretest, posttest, data=mydata100)  + 
  coord_trans(x="log10", y="log10")

ggplot(mydata100, aes( x=pretest, y=posttest) ) +
  geom_point() + coord_trans(x="log10", y="log10") 

# ---Aspect Ratio---

# This forces x and y to be equal.
qplot(pretest, posttest) + coord_equal()
 
# This sets aspect ratio to height/width.
qplot(pretest, posttest) + coord_equal(ratio=1/4)

#---Multiframe Plots: Barchart Example---

# Clears the page, otherwise new plots 
# will appear on top of old.

postscript("GGbarMultiframeRepeated.eps",
  paper="special",width=8.00,height=8.00)

grid.newpage()

# Sets up a 2 by 2 grid to plot into.
pushViewport( viewport(layout=grid.layout(2,2) ) )

# Barchart dodged in row 1, column 1.
myPlot <- ggplot(mydata100, 
    aes(gender, fill=workshop) ) + 
  geom_bar(position="stack") + 
  scale_fill_grey(start = 0, end = 1) +
  opts( title="position=stack " )
print(myPlot, vp=viewport(
  layout.pos.row=1, 
  layout.pos.col=1) )

# Barchart stacked, in row 1, column 2.
myPlot <- ggplot(mydata100, 
    aes(gender, fill=workshop) ) + 
  geom_bar(position="fill") + 
  scale_fill_grey(start = 0, end = 1) + 
  opts( title="position=fill" )
print(myPlot, vp=viewport(
  layout.pos.row=1, 
  layout.pos.col=2) )

# Barchart dodged, given frames, 
# in row 2, columns 1 and 2.
myPlot <- ggplot(mydata100, 
    aes(gender, fill=workshop) ) + 
  geom_bar(position="dodge")  + 
  scale_fill_grey(start = 0, end = 1) + 
  opts( title="position=dodge" )
print(myPlot, vp=viewport(
  layout.pos.row=2, 
  layout.pos.col=1:2) )

dev.off()

#---Multiframe Scatterplots---

postscript("GGscatterMultiframe.eps",
  paper="special",width=4.75,height=4.75)

# Clears the page, otherwise new plots will appear on top of old.
grid.newpage()

# Sets up a 2 by 2 grid to plot into.
pushViewport( viewport(layout=grid.layout(2,2) ) )

# Scatterplot of points
myPlot <- qplot(pretest, posttest,main="geom=point") 
print(myPlot, vp=viewport(
  layout.pos.row=1, 
  layout.pos.col=1) )

myPlot <- qplot( pretest, posttest, 
          geom="line", main="geom=line" )
print(myPlot, vp=viewport(
  layout.pos.row=1, 
  layout.pos.col=2) )

myPlot <- qplot( pretest, posttest, 
          geom="path", main="geom=path" )
print(myPlot, vp=viewport(
  layout.pos.row=2, 
  layout.pos.col=1) )

myPlot <- ggplot( mydata100, aes(pretest, posttest) ) + 
          geom_segment( aes(x=pretest, y=posttest, 
                         xend=pretest, yend=58) ) + 
          opts( title="geom_segment" )

print(myPlot, 
  vp=viewport(layout.pos.row=2, layout.pos.col=2) )

dev.off()

# ---Multiframe Scatterplot for Jitter---

postscript("GGLikert.eps",
  paper="special",width=4.75,height=3.5)

grid.newpage()
pushViewport( viewport(layout=grid.layout(1,2) ) )

# Scatterplot without
myPlot <- qplot( q1, q4,
          main="Likert Scale Without Jitter")
print(myPlot, vp=viewport(
  layout.pos.row=1, 
  layout.pos.col=1) )

myPlot <- qplot(q1, q4, 
          position=position_jitter(width=.3,height=.3),
          main="Likert scale with jitter") 
 
print(myPlot, vp=viewport(
  layout.pos.row=1, 
  layout.pos.col=2) ) 

dev.off()

# ---Detailed Comparison of qplot and ggplot---

qplot(pretest, posttest, 
  geom=c("point","smooth"), method="lm" ) 

# Or ggplot with default settings:

ggplot(mydata100, aes(x=pretest, y=posttest) ) +
  geom_point() + 
  geom_smooth(method="lm")

# Or with all the defaults displayed:
ggplot() +
layer(
  data=mydata100,
  mapping=aes(x=pretest, y=posttest),
  geom="point",
  stat="identity"
) +
layer(
  data=mydata100,
  mapping=aes(x=pretest, y=posttest),
  geom="smooth",
  stat="smooth",
  method="lm"
) +
coord_cartesian()





