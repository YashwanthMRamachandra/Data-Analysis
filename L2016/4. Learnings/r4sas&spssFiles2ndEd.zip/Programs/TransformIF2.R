# R Program for Multiple Conditional Transformations.
# Filename: TransformIF2.R

setwd("c:/myRfolder")
load(file = "mydata.RData")
attach(mydata)
mydata

# Using the ifelse approach.
mydata$score1 <- ifelse( gender == "f",
  (2 * q1) + q2,  # Score 1 for females.
  (20* q1) + q2   # Score 1 for males.
)
mydata$score2 <- ifelse( gender == "f",
  (3  * q1) + q2,  # Score 2 for females.
  (30 * q1) + q2   # Score 2 for males.
)
mydata

# Using the index approach.

load(file = "mydata.RData")

# Create names in data frame.
detach(mydata)
mydata <- data.frame(mydata, score1 = NA, score2 = NA)
mydata
attach(mydata)

# Find which are males and females.
gals <- which( gender == "f" )
gals
guys <- which( gender == "m" )
guys

mydata[gals, "score1"] <-  2 * q1[gals] + q2[gals]
mydata[gals, "score2"] <-  3 * q1[gals] + q2[gals]
mydata[guys, "score1"] <- 20 * q1[guys] + q2[guys]
mydata[guys, "score2"] <- 30 * q1[guys] + q2[guys]
mydata

# Clean up.
rm(guys, gals)