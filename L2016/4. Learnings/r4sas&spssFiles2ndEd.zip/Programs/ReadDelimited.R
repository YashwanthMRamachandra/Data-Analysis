# R Program to Read Delimited Text Files.
# Filename: ReadDelimited.R

setwd("c:/myRfolder")

#---Comma Delimited Files---

# Read comma delimited file.
# With id variable not named.

mydata <- read.csv("mydata.csv")
mydata

# This time with id named in the header

mydata <- read.csv("mydataID.csv",
  row.names = "id")
mydata

#---Tab Delimited Files---

# Read a tab delimited file with named ID column.
mydata <- read.delim("mydata.tab")
mydata

count.fields("mydata.tab", sep = "\t")

# Again with ID named in the header
mydata <- read.delim("mydataID.tab",
  row.names = "id")
mydata

# ---Reading Text from a Web Site---

myURL <- "http://sites.google.com/site/r4statistics/mydata.csv"
mydata <- read.csv(myURL)
mydata

# ---Reading Text from the Clipboard---

# Copy a column of numbers or words, then:
myvector <- readClipboard()
myvector

# Open mydata.csv, select & copy contents, then:
mydata <- read.delim("clipboard", header = TRUE)
mydata

#---Missing Values for Character Variables---

mydata <- read.csv("mydataID.csv",
  row.names   = "id",
  strip.white = TRUE,
  na.strings  = "" )
mydata

#---Skipping Variables in Delimited Text Files---

myCols <- read.delim("mydata.tab",
  strip.white = TRUE,
  na.strings  = "",
  colClasses  = c("integer", "integer", "character",
  "NULL", "NULL", "integer", "integer") )
myCols

# Clean up and save workspace.
rm(myCols)

save.image(file = "mydata.RData")