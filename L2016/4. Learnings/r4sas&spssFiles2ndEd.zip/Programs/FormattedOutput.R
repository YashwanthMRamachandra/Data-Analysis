# R Program for Formatting Output
# Filename: FormattedOutput.R

options(width = 60)
setwd("c:/myRfolder")
load("mydata.RData")
attach(mydata)

library("xtable")

# Formatting a Data Frame

print(mydata)
myXtable <- xtable(mydata)
class(myXtable)

print(myXtable, type = "html")
print(myXtable, type = "latex")

# Formatting a Linear Model

mymodel <- lm( q4 ~ q1 + q2 + q3, data = mydata)
myXtable <- xtable(mymodel)

label(myXtable) <- c("xtableOutput")
caption(myXtable) <-
  c("Linear model results formatted by xtable")

print(myXtable, type = "html")
print(myXtable, type = "latex")