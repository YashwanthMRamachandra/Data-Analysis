# R Program for Geographic Maps
# Filename: Maps.R

library(maps)
library(ggplot2)
myStates <- map_data("state")
head(myStates)
myStates[ myStates$region == "new york", ]

qplot(long, lat, data = myStates, group = group, 
  geom = "path", asp=1)
  
ggplot(data = myStates, aes(long, lat, group = group) )+
  geom_path() +
  coord_map()

myArrests <- USArrests
head(myArrests)

myArrests$region <- tolower( rownames(USArrests) )
head(myArrests)

myBoth <- merge( 
  myStates, 
  myArrests, by = "region")
myBoth[1:4, c(1:5, 8)]

myBoth <- myBoth[order(myBoth$order), ]
myBoth[1:4, c(1:5,8)]

qplot(long, lat, data = myBoth, group = group, 
  fill = Assault, geom = "polygon", asp=1) +
  scale_fill_continuous(low = "grey80", high = "black")
  
ggplot(data = myBoth,
    aes(long, lat, fill = Assault, group = group) )+
  geom_polygon() +
  coord_map() +
  scale_fill_continuous(low = "grey80", high = "black")