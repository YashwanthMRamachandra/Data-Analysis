# Program to Read an ODBC connection.
# Filename: ReadODBC.R

setwd("c:/myRfolder")

library(RODBC)

myConnection <- odbcConnectExcel("mydata.xls")

mydata <- sqlFetch(myConnection, "Sheet1")
mydata

close(myConnection)