# R Program for Character String Manipulations
# Filename: CharacterStrings.R

gender <-c("m", "f", "m", NA, "m", "f", "m", "f")
gender

options(width = 58)
letters
LETTERS

library("stringr")
myVars <- str_c("Var", LETTERS[1:6])
myVars

setwd("c:/myRfolder")
giants <- read.fwf(
   file  = "giants.txt",
   width = c(15,11,11), 
   col.names  = c("name",      "born",      "died"),
   colClasses = c("character", "character", "POSIXct")
)
giants

str_length( giants$name )

giants[ giants$name == "R.A. Fisher", ]
giants[ giants$name == "R.A. Fisher    ", ]

giants$name <- str_trim(giants$name)
attach(giants)
str_length(name)

toupper(name)
tolower(name)
library(ggplot2)
firstUpper( tolower(name) )

str_sub(name, 1, 5)

myNamesMatrix <- str_split_fixed(name, " ", 2)
myNamesMatrix

myFirst <- myNamesMatrix[ ,1]
myFirst
myLast  <- myNamesMatrix[ ,2]
myLast

myFirst <- str_replace_all(myFirst, "R.A.", "Ronald A.")

myLastFirst <- str_c( myLast, ", ", myFirst)
myLastFirst

myObs <- myLast == "Tukey"
myObs
myObs <- which(myLast == "Tukey")
myObs
giants[ myObs, ]

myObs <- str_detect(myLast, "key")
myObs

myTable <- c("Box", "Bayes", "Fisher", "Tukey")
myObs <- myLast %in% myTable
myObs
name[ myObs ]

myObs <- str_detect( myLast, "Box|Bayes|Fish|key" )
myObs
name[ myObs ]

myAthruM <- str_detect(myLastFirst, "^[A-M]")
myAthruM
name[ myAthruM ]
name[!myAthruM ]