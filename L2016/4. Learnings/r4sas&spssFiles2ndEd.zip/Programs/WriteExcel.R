# Program to Write Excel Files
# Filename: WriteExcel.R

# Do this once:
install.packages("xlsReadWrite")
library("xlsReadWrite")
xls.getshlib()

# Do this each time:
library("xlsReadWrite")
setwd("c:/myRfolder")

load("mydata.RData")
write.xls(mydata, "mydataFromR.xls")