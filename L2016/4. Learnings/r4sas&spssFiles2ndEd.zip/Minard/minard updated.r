# R Program to recreate Minard's plot of Napoleon's march.
# Original program by Hadley Wickham.
# Tweaked by Bob Muenchen, adding labels and placing both graphs on one plot.
# Updated 11/7/2010 for 2nd edition of R for SAS and SPSS Users

setwd("C:\\Users\\Bob\\Documents\\A1\\Books\\R for SAS and SPSS Users\\R for SAS & SPSS - 2nd Edition\\R-for-SAS-and-SPSS-Users-Files-2nd-Edition\\Minard")
      
library(ggplot2)

troops <- read.table("troops.txt", header=T)
head(troops)

# Just the troops
ggplot(troops, aes(x = Longitude, y = Latitude)) + 
  geom_path( 
    aes(size = Survivors, 
	  colour = Direction, 
	   group = Group)) +
  scale_colour_manual( values = c("grey75","grey40") )
	
cities <- read.table("cities.txt", header=T)
head(cities)

# Just the cities
 ggplot(cities, aes(x = Longitude, y = Latitude)) + 
  geom_point() + 
  geom_text( aes(label = City), hjust=0, vjust=1, size=4) +
  scale_x_continuous( limits = c(24, 39) )

# Troops and Cities together
troopsNcitiesPlot <- 
ggplot(cities, aes(x = Longitude, y = Latitude)) +  
  geom_path( data=troops, 
    aes(size = Survivors, 
	  colour = Direction, 
	   group = Group) ) + 
  geom_point() + 
  geom_text( aes(label = City), hjust=0, vjust=1, size=4) +
  scale_size( to = c(1, 10) ) + 
  scale_colour_manual( values = c("grey75","grey40") ) +
  scale_x_continuous( limits = c(24, 39) )
print(troopsNcitiesPlot)
ggsave(file = "March.eps", width=16, height=4)

temps <- read.table("temps.txt", header=T)
head(temps)

library("lubridate")
temps$Date <- dmy( temps$Date )
Month <- month( temps$Date, label=TRUE)
Day   <- day(   temps$Date) 
# debugging: dmy("18OCT1812")

library("stringr")
temps$dateLabel <- str_c(Month, Day) 
rm( Month, Day )
head(temps) 

# Create and save plot of temperature by longitude.
tempsPlot <- ggplot(temps, aes(Longitude, Temperature) ) +
  geom_line() + 
  geom_text(aes(label = dateLabel ), vjust=1) + 
  scale_x_continuous( limits = c(24, 39) ) 
print(tempsPlot)
ggsave(file = "Temperatures.pdf", width=16, height=4)

ggplot(temps, aes(Longitude, Temperature) ) +
  geom_line() + 
  geom_text(aes(label = Date ), vjust=1) + 
  scale_x_continuous( limits = c(24, 39) ) 




# Printing both to one plot to match Minard's original.
# First to windows device.
windows(width=16, height=7)
grid.newpage()
pushViewport( viewport(layout=grid.layout(4,100) ) )
print(troopsNcitiesPlot, vp=viewport(
   layout.pos.row=1:3, 
   layout.pos.col=1:100) )
print(tempsPlot, vp=viewport(
   layout.pos.row=4, 
   layout.pos.col=1:93) )

# And again to PDF file. Note that ggsave function cannot
# save a multiframe grid, so we need to use the pdf function.
pdf(file="both.pdf", width=16, height=7)
grid.newpage()
pushViewport( viewport(layout=grid.layout(4,100) ) )
print(troopsNcitiesPlot, vp=viewport(
   layout.pos.row=1:3, 
   layout.pos.col=1:100) )
print(tempPlot, vp=viewport(
   layout.pos.row=4, 
   layout.pos.col=1:94) )
dev.off()


